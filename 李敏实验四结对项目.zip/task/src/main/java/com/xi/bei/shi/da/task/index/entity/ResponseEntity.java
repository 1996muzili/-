package com.xi.bei.shi.da.task.index.entity;

import lombok.Data;

@Data
public class ResponseEntity {
    private String key;
    private Integer value;
}
